extends Control

const GAME_SCENE := "res://game.tscn"
const MONSTER_MODEL := "res://assets/models/ash_titan.glb"

var settings_panel: PanelContainer
var preview_model: Node3D
var preview_viewport: SubViewport

func _ready() -> void:
    _build_menu()

func _build_menu() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var bg := ColorRect.new()
    bg.color = Color(0.012, 0.014, 0.023, 1)
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)

    var glow := ColorRect.new()
    glow.color = Color(0.22, 0.025, 0.025, 0.18)
    glow.anchor_left = 0.42
    glow.anchor_right = 1.0
    glow.anchor_top = 0.0
    glow.anchor_bottom = 1.0
    glow.offset_left = 0
    glow.offset_right = 0
    glow.offset_top = 0
    glow.offset_bottom = 0
    bg.add_child(glow)

    var layout := HBoxContainer.new()
    layout.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layout.add_theme_constant_override("separation", 0)
    add_child(layout)

    var left := PanelContainer.new()
    left.custom_minimum_size = Vector2(430, 0)
    left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    left.size_flags_stretch_ratio = 0.42
    var panel_style := StyleBoxFlat.new()
    panel_style.bg_color = Color(0.018, 0.021, 0.032, 0.96)
    panel_style.border_width_right = 1
    panel_style.border_color = Color(0.45, 0.09, 0.07, 0.8)
    left.add_theme_stylebox_override("panel", panel_style)
    layout.add_child(left)

    var margins := MarginContainer.new()
    margins.add_theme_constant_override("margin_left", 48)
    margins.add_theme_constant_override("margin_right", 48)
    margins.add_theme_constant_override("margin_top", 28)
    margins.add_theme_constant_override("margin_bottom", 28)
    margins.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    margins.size_flags_vertical = Control.SIZE_EXPAND_FILL
    left.add_child(margins)
    var column := VBoxContainer.new()
    column.alignment = BoxContainer.ALIGNMENT_CENTER
    column.add_theme_constant_override("separation", 16)
    column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    margins.add_child(column)

    var eyebrow := _label("SURVIVAL HORROR  /  FIRST PERSON", 12, Color(0.72, 0.35, 0.28))
    column.add_child(eyebrow)
    var title := _label("IRON\nNIGHT", 64, Color(0.94, 0.91, 0.88))
    title.add_theme_font_size_override("font_size", 64)
    title.add_theme_color_override("font_shadow_color", Color(0.65, 0.035, 0.025, 0.9))
    title.add_theme_constant_override("shadow_offset_x", 3)
    title.add_theme_constant_override("shadow_offset_y", 4)
    column.add_child(title)
    var subtitle := _label("THE LAST SANCTUM", 15, Color(0.72, 0.73, 0.78))
    column.add_child(subtitle)
    var line := ColorRect.new()
    line.custom_minimum_size = Vector2(0, 2)
    line.color = Color(0.66, 0.10, 0.075)
    column.add_child(line)
    _add_menu_button(column, "НАЧАТЬ ИГРУ", _start_game, true)
    _add_menu_button(column, "НАСТРОЙКИ", _show_settings)
    _add_menu_button(column, "УПРАВЛЕНИЕ", _show_controls)
    _add_menu_button(column, "ВЫХОД", _exit_game)
    var footer := _label("WAVES WILL COME. DO NOT LET THEM IN.", 10, Color(0.43, 0.46, 0.53))
    footer.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    column.add_child(footer)

    var right := Control.new()
    right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    right.size_flags_stretch_ratio = 0.58
    layout.add_child(right)
    _build_monster_preview(right)
    var right_title := _label("THE ASH TITAN", 20, Color(0.87, 0.24, 0.16))
    right_title.anchor_left = 0.54
    right_title.anchor_top = 0.84
    right_title.anchor_right = 0.96
    right_title.anchor_bottom = 0.91
    right_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    right.add_child(right_title)
    var right_sub := _label("IT HEARS YOUR HEARTBEAT", 11, Color(0.68, 0.68, 0.72))
    right_sub.anchor_left = 0.54
    right_sub.anchor_top = 0.91
    right_sub.anchor_right = 0.96
    right_sub.anchor_bottom = 0.96
    right_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    right.add_child(right_sub)

func _build_monster_preview(parent: Control) -> void:
    var holder := SubViewportContainer.new()
    holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    holder.stretch = true
    holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(holder)
    preview_viewport = SubViewport.new()
    preview_viewport.size = Vector2i(900, 900)
    preview_viewport.transparent_bg = true
    preview_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    holder.add_child(preview_viewport)

    var world := Node3D.new()
    preview_viewport.add_child(world)
    var env_node := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.012, 0.014, 0.023, 0.0)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.42, 0.38, 0.42)
    env.ambient_light_energy = 0.9
    env.glow_enabled = true
    env_node.environment = env
    world.add_child(env_node)

    var camera := Camera3D.new()
    camera.position = Vector3(0, 2.1, 7.2)
    camera.look_at(Vector3(0, 1.7, 0), Vector3.UP)
    camera.fov = 38
    world.add_child(camera)
    camera.current = true
    var key := DirectionalLight3D.new()
    key.rotation_degrees = Vector3(-32, -28, 0)
    key.light_energy = 2.0
    key.shadow_enabled = true
    world.add_child(key)
    var rim := OmniLight3D.new()
    rim.position = Vector3(2.5, 2.8, -1.8)
    rim.light_color = Color(1.0, 0.08, 0.035)
    rim.light_energy = 5.0
    rim.omni_range = 8
    world.add_child(rim)
    var floor := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(12, 12)
    floor.mesh = plane
    floor.position.y = -0.12
    var floor_mat := StandardMaterial3D.new()
    floor_mat.albedo_color = Color(0.035, 0.027, 0.035)
    floor_mat.roughness = 0.95
    floor.material_override = floor_mat
    world.add_child(floor)
    var packed := load(MONSTER_MODEL) as PackedScene
    if packed != null:
        preview_model = packed.instantiate() as Node3D
        if preview_model != null:
            preview_model.position = Vector3(0, 0, 0)
            preview_model.scale = Vector3.ONE * 1.65
            world.add_child(preview_model)

func _process(delta: float) -> void:
    if is_instance_valid(preview_model):
        preview_model.rotate_y(delta * 0.22)

func _label(value: String, size: int, color: Color) -> Label:
    var l := Label.new()
    l.text = value
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    return l

func _add_menu_button(parent: VBoxContainer, caption: String, callback: Callable, primary := false) -> void:
    var button := Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(0, 58)
    button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    button.add_theme_font_size_override("font_size", 18)
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.34, 0.045, 0.035, 0.95) if primary else Color(0.055, 0.061, 0.078, 0.95)
    normal.border_width_left = 3
    normal.border_color = Color(0.85, 0.15, 0.09) if primary else Color(0.25, 0.28, 0.34)
    normal.content_margin_left = 18
    normal.corner_radius_top_left = 3
    normal.corner_radius_bottom_left = 3
    button.add_theme_stylebox_override("normal", normal)
    var hover := normal.duplicate() as StyleBoxFlat
    hover.bg_color = Color(0.52, 0.07, 0.045) if primary else Color(0.10, 0.11, 0.15)
    button.add_theme_stylebox_override("hover", hover)
    button.add_theme_stylebox_override("pressed", hover)
    button.pressed.connect(callback)
    parent.add_child(button)

func _start_game() -> void:
    get_tree().change_scene_to_file(GAME_SCENE)

func _show_settings() -> void:
    _show_popup("НАСТРОЙКИ", "Управление чувствительностью мыши и качество графики можно настроить в следующих обновлениях.

На телефоне используй сенсорные кнопки и свайп по правой части экрана.")

func _show_controls() -> void:
    _show_popup("УПРАВЛЕНИЕ", "ПК: WASD — движение, мышь — обзор, ЛКМ — огонь, Q — меч, G — граната, R — перезарядка, 1/2 — оружие.

ТЕЛЕФОН: левый джойстик — движение, свайп справа — обзор, кнопки FIRE / SWORD / BOOM / JUMP / RELOAD — действия.")

func _show_popup(caption: String, body: String) -> void:
    if is_instance_valid(settings_panel):
        settings_panel.queue_free()
    settings_panel = PanelContainer.new()
    settings_panel.set_anchors_preset(Control.PRESET_CENTER)
    settings_panel.position = Vector2(-245, -130)
    settings_panel.size = Vector2(490, 260)
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.025, 0.028, 0.04, 0.98)
    style.border_color = Color(0.65, 0.10, 0.07)
    style.set_border_width_all(2)
    settings_panel.add_theme_stylebox_override("panel", style)
    add_child(settings_panel)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 14)
    settings_panel.add_child(col)
    var heading := _label(caption, 23, Color(0.95, 0.22, 0.14))
    col.add_child(heading)
    var text := _label(body, 14, Color(0.82, 0.83, 0.87))
    text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    text.size_flags_vertical = Control.SIZE_EXPAND_FILL
    col.add_child(text)
    var close := Button.new()
    close.text = "ЗАКРЫТЬ"
    close.custom_minimum_size.y = 42
    close.pressed.connect(func(): settings_panel.queue_free())
    col.add_child(close)

func _exit_game() -> void:
    get_tree().quit()
