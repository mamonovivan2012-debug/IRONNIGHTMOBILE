extends Node3D

const PlayerScript = preload("res://scripts/player.gd")
const MonsterScript = preload("res://scripts/monster.gd")
const HUDScript = preload("res://scripts/hud.gd")

var player: CharacterBody3D
var hud: CanvasLayer
var wave := 1
var kills := 0
var spawn_timer := 0.0
var alive_to_spawn := 0
var game_over := false
var arena_radius := 34.0

func _ready() -> void:
    _build_world()
    player = CharacterBody3D.new()
    player.set_script(PlayerScript)
    player.name = "Player"
    add_child(player)
    player.position = Vector3(0, 1.2, 8)
    player.health_changed.connect(_on_health_changed)
    player.died.connect(_on_player_died)
    hud = CanvasLayer.new()
    hud.set_script(HUDScript)
    add_child(hud)
    hud.bind_game(self, player)
    _start_wave()

func _process(delta: float) -> void:
    if game_over:
        return
    if alive_to_spawn > 0:
        spawn_timer -= delta
        if spawn_timer <= 0.0:
            _spawn_monster()
            alive_to_spawn -= 1
            spawn_timer = max(0.55, 1.7 - wave * 0.07)
    if get_tree().get_nodes_in_group("monsters").is_empty() and alive_to_spawn == 0:
        await get_tree().create_timer(2.0).timeout
        if not game_over and get_tree().get_nodes_in_group("monsters").is_empty() and alive_to_spawn == 0:
            wave += 1
            _start_wave()

func _start_wave() -> void:
    alive_to_spawn = mini(3 + wave * 2, 18)
    spawn_timer = 0.8
    if is_instance_valid(hud):
        hud.set_wave(wave)

func _spawn_monster() -> void:
    var mob := CharacterBody3D.new()
    mob.set_script(MonsterScript)
    mob.player = player
    mob.wave = wave
    add_child(mob)
    var angle := randf() * TAU
    var distance := randf_range(19.0, 29.0)
    mob.global_position = Vector3(cos(angle) * distance, 0.0, sin(angle) * distance)
    mob.killed.connect(_on_monster_killed)

func _on_monster_killed() -> void:
    kills += 1
    if is_instance_valid(hud):
        hud.set_kills(kills)

func _on_health_changed(value: float, maximum: float) -> void:
    if is_instance_valid(hud):
        hud.set_health(value, maximum)

func _on_player_died() -> void:
    game_over = true
    if is_instance_valid(hud):
        hud.show_game_over(kills, wave)

func _build_world() -> void:
    randomize()
    var world := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.008, 0.018, 0.055)
    sky_mat.sky_horizon_color = Color(0.20, 0.055, 0.075)
    sky_mat.ground_bottom_color = Color(0.008, 0.009, 0.016)
    sky_mat.ground_horizon_color = Color(0.07, 0.025, 0.04)
    sky.sky_material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.30, 0.34, 0.48)
    env.ambient_light_energy = 0.55
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.glow_enabled = true
    env.glow_intensity = 0.65
    env.glow_bloom = 0.12
    env.fog_enabled = true
    env.fog_light_color = Color(0.16, 0.055, 0.075)
    env.fog_density = 0.012
    world.environment = env
    add_child(world)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -28, 0)
    sun.light_energy = 1.35
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 70
    add_child(sun)

    _make_box("Arena floor", Vector3(0, -0.6, 0), Vector3(72, 1, 72), Color(0.045, 0.052, 0.075), true)
    _make_box("Outer wall north", Vector3(0, 2, -36), Vector3(72, 5, 1), Color(0.075, 0.075, 0.105), true)
    _make_box("Outer wall south", Vector3(0, 2, 36), Vector3(72, 5, 1), Color(0.075, 0.075, 0.105), true)
    _make_box("Outer wall east", Vector3(36, 2, 0), Vector3(1, 5, 72), Color(0.075, 0.075, 0.105), true)
    _make_box("Outer wall west", Vector3(-36, 2, 0), Vector3(1, 5, 72), Color(0.075, 0.075, 0.105), true)

    for i in range(12):
        var a := TAU * float(i) / 12.0
        var p := Vector3(cos(a) * 27, 0, sin(a) * 27)
        _make_box("Gothic pillar", p + Vector3(0, 2.4, 0), Vector3(1.8, 5, 1.8), Color(0.09, 0.095, 0.14), true)
        _make_sphere_light(p + Vector3(0, 4.7, 0), Color(1.0, 0.12, 0.055), 2.5, 5.5)
    for i in range(18):
        var x := randf_range(-23, 23)
        var z := randf_range(-23, 23)
        if Vector2(x, z).length() > 9:
            _make_box("Ruin cover", Vector3(x, 0.8, z), Vector3(randf_range(2, 4), randf_range(1.2, 2.5), randf_range(2, 4)), Color(0.065, 0.075, 0.105), true)
    for x in range(-30, 31, 6):
        _make_box("Floor rune", Vector3(x, -0.075, 0), Vector3(0.06, 0.025, 55), Color(0.22, 0.025, 0.035), false, true)
    _build_textured_props()

func _make_box(label: String, pos: Vector3, size: Vector3, color: Color, collision: bool, emissive := false) -> void:
    var body := StaticBody3D.new() if collision else Node3D.new()
    body.name = label
    body.position = pos
    add_child(body)
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.88
    if label.find("Arena floor") >= 0:
        mat.albedo_texture = load("res://assets/textures/ground_mud_gravel.png")
        mat.roughness_texture = load("res://assets/textures/ground_mud_gravel_roughness.png")
        mat.uv1_scale = Vector3(12, 12, 1)
    elif label.find("Outer wall") >= 0 or label.find("Gothic pillar") >= 0 or label.find("Ruin cover") >= 0:
        mat.albedo_texture = load("res://assets/textures/ruin_stone.png")
        mat.roughness_texture = load("res://assets/textures/ruin_stone_roughness.png")
        mat.uv1_scale = Vector3(3, 3, 1)
    if emissive:
        mat.emission_enabled = true
        mat.emission = color
        mat.emission_energy_multiplier = 1.8
    mesh.material_override = mat
    body.add_child(mesh)
    if collision:
        var shape := CollisionShape3D.new()
        var box_shape := BoxShape3D.new()
        box_shape.size = size
        shape.shape = box_shape
        body.add_child(shape)

func _make_sphere_light(pos: Vector3, color: Color, energy: float, range_value: float) -> void:
    var lamp := OmniLight3D.new()
    lamp.position = pos
    lamp.light_color = color
    lamp.light_energy = energy
    lamp.omni_range = range_value
    lamp.shadow_enabled = false
    add_child(lamp)
    var orb := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.22
    sphere.height = 0.44
    orb.mesh = sphere
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.albedo_color = color
    mat.emission_enabled = true
    mat.emission = color
    mat.emission_energy_multiplier = 4.0
    orb.material_override = mat
    orb.position = pos
    add_child(orb)

func _build_textured_props() -> void:
    var bark := StandardMaterial3D.new()
    bark.albedo_texture = load("res://assets/textures/tree_bark.png")
    bark.roughness_texture = load("res://assets/textures/tree_bark_roughness.png")
    bark.roughness = 0.94
    var leaves := StandardMaterial3D.new()
    leaves.albedo_texture = load("res://assets/textures/pine_needles.png")
    leaves.roughness_texture = load("res://assets/textures/pine_needles_roughness.png")
    leaves.roughness = 0.96
    var rust := StandardMaterial3D.new()
    rust.albedo_texture = load("res://assets/textures/barrel_rust.png")
    rust.roughness_texture = load("res://assets/textures/barrel_rust_roughness.png")
    rust.roughness = 0.82
    rust.metallic = 0.38
    var wood := StandardMaterial3D.new()
    wood.albedo_texture = load("res://assets/textures/tree_bark.png")
    wood.roughness = 0.95

    # Dead pines around the arena perimeter.
    for i in range(14):
        var angle := TAU * float(i) / 14.0 + 0.18
        var radius := randf_range(30.0, 34.0)
        var root := Node3D.new()
        root.name = "Textured dead pine %02d" % i
        root.position = Vector3(cos(angle) * radius, 0, sin(angle) * radius)
        add_child(root)
        var trunk := MeshInstance3D.new()
        var trunk_mesh := CylinderMesh.new()
        trunk_mesh.top_radius = 0.12
        trunk_mesh.bottom_radius = 0.34
        trunk_mesh.height = randf_range(4.0, 6.2)
        trunk.mesh = trunk_mesh
        trunk.material_override = bark
        trunk.position.y = trunk_mesh.height * 0.5
        root.add_child(trunk)
        for tier in range(3):
            var crown := MeshInstance3D.new()
            var cone := ConeMesh.new()
            cone.top_radius = 0.0
            cone.bottom_radius = 1.35 - float(tier) * 0.22
            cone.height = 2.5
            crown.mesh = cone
            crown.material_override = leaves
            crown.position.y = 2.5 + float(tier) * 1.0
            root.add_child(crown)

    # Rusted fuel drums and timber supply crates as arena cover.
    for i in range(12):
        var angle := TAU * float(i) / 12.0 + 0.4
        var radius := randf_range(12.0, 25.0)
        var prop := Node3D.new()
        prop.name = "Rusted fuel barrel %02d" % i
        prop.position = Vector3(cos(angle) * radius, 0, sin(angle) * radius)
        prop.rotation.y = randf_range(0.0, TAU)
        add_child(prop)
        var drum := MeshInstance3D.new()
        var drum_mesh := CylinderMesh.new()
        drum_mesh.top_radius = 0.48
        drum_mesh.bottom_radius = 0.48
        drum_mesh.height = 1.25
        drum.mesh = drum_mesh
        drum.material_override = rust
        drum.position.y = 0.625
        prop.add_child(drum)
        for band_y in [0.18, 1.05]:
            var band := MeshInstance3D.new()
            var band_mesh := TorusMesh.new()
            band_mesh.inner_radius = 0.455
            band_mesh.outer_radius = 0.49
            band.mesh = band_mesh
            var band_mat := StandardMaterial3D.new()
            band_mat.albedo_color = Color(0.16, 0.17, 0.19)
            band_mat.metallic = 0.8
            band_mat.roughness = 0.48
            band.material_override = band_mat
            band.position.y = band_y
            prop.add_child(band)

    for i in range(10):
        var angle := TAU * float(i) / 10.0 + 0.1
        var radius := randf_range(10.0, 24.0)
        var crate := MeshInstance3D.new()
        var box := BoxMesh.new()
        box.size = Vector3(1.3, 1.1, 1.2)
        crate.mesh = box
        crate.material_override = wood
        crate.position = Vector3(cos(angle) * radius, 0.55, sin(angle) * radius)
        crate.rotation.y = randf_range(0.0, TAU)
        add_child(crate)
