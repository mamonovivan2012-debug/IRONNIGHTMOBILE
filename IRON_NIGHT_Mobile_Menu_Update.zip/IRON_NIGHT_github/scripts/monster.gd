extends CharacterBody3D

signal killed

var player: Node3D
var wave := 1
var health := 85.0
var speed := 2.7
var attack_timer := 0.0
var hit_flash := 0.0
var body_mesh: Node3D
var eye_lights: Array[OmniLight3D] = []
var gravity := 18.0

func _ready() -> void:
    add_to_group("monsters")
    health = 85.0 + wave * 12.0
    speed = 2.5 + minf(wave * 0.12, 2.0)
    var capsule := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.58
    shape.height = 2.25
    capsule.shape = shape
    capsule.position.y = 1.12
    add_child(capsule)

    var packed_resource: Resource = load("res://assets/models/ash_titan.glb")
    if packed_resource == null or not (packed_resource is PackedScene):
        push_error("Could not load imported model scene: res://assets/models/ash_titan.glb. Run Godot editor import before launching/exporting.")
        return
    var packed: PackedScene = packed_resource as PackedScene
    body_mesh = packed.instantiate()
    body_mesh.name = "Ash Titan — imported character model"
    body_mesh.scale = Vector3.ONE
    add_child(body_mesh)
    var hide_texture: Texture2D = load("res://assets/textures/monster_ashen_hide.png") as Texture2D
    var hide_roughness: Texture2D = load("res://assets/textures/monster_ashen_hide_roughness.png") as Texture2D
    if hide_texture != null:
        var hide_material := StandardMaterial3D.new()
        hide_material.albedo_texture = hide_texture
        hide_material.roughness_texture = hide_roughness
        hide_material.roughness = 0.88
        hide_material.metallic = 0.04
        _apply_hide_material(body_mesh, hide_material)

func _apply_hide_material(node: Node, material: Material) -> void:
    if node is MeshInstance3D:
        (node as MeshInstance3D).material_override = material
    for child in node.get_children():
        _apply_hide_material(child, material)

func _physics_process(delta: float) -> void:
    if not is_instance_valid(player):
        return
    attack_timer = maxf(0, attack_timer - delta)
    hit_flash = maxf(0, hit_flash - delta)
    if hit_flash > 0:
        body_mesh.scale = Vector3.ONE * 1.08
    else:
        body_mesh.scale = Vector3.ONE
    var target := player.global_position
    var flat := target - global_position
    flat.y = 0
    var distance := flat.length()
    if distance > 1.5:
        var dir := flat.normalized()
        velocity.x = dir.x * speed
        velocity.z = dir.z * speed
        look_at(Vector3(target.x, global_position.y, target.z), Vector3.UP)
    else:
        velocity.x = move_toward(velocity.x, 0, speed * 5 * delta)
        velocity.z = move_toward(velocity.z, 0, speed * 5 * delta)
        if attack_timer <= 0 and player.has_method("take_damage"):
            player.take_damage(12.0 + wave * 0.8)
            attack_timer = 1.05
    if not is_on_floor():
        velocity.y -= gravity * delta
    move_and_slide()

func take_damage(amount: float, hit_position: Vector3) -> void:
    health -= amount
    hit_flash = 0.12
    if health <= 0:
        _die()

func _die() -> void:
    killed.emit()
    var burst := GPUParticles3D.new()
    burst.position = global_position + Vector3.UP
    burst.amount = 28
    burst.lifetime = 0.65
    burst.one_shot = true
    var pm := ParticleProcessMaterial.new()
    pm.direction = Vector3.UP
    pm.spread = 180
    pm.initial_velocity_min = 2
    pm.initial_velocity_max = 8
    pm.gravity = Vector3(0, -7, 0)
    burst.process_material = pm
    var sphere := SphereMesh.new()
    sphere.radius = 0.06
    sphere.height = 0.12
    burst.draw_pass_1 = sphere
    get_tree().current_scene.add_child(burst)
    burst.emitting = true
    get_tree().create_timer(1.0).timeout.connect(burst.queue_free)
    queue_free()
