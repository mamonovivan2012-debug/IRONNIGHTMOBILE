IRON NIGHT texture set

Albedo textures: weapon_worn_steel, monster_ashen_hide, ground_mud_gravel, ruin_stone, barrel_rust, tree_bark, pine_needles.
Each has a matching *_roughness.png grayscale map. Textures are 1024x1024 PNG and designed for tiling/repetition.
